import React, { useState, useEffect } from "react";
import "../../styles/RoomManagement.css";

import RoomApi from "./apiCalls/RoomCalls.jsx";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const RoomManagement = () => {
    const [rooms, setRooms] = useState([]);
    const [form, setForm] = useState({
        name: "",
        tables: 0,
        island: false,
    });
    const [editingIndex, setEditingIndex] = useState(null);
    const [loading, setLoading] = useState(true);
    const [formSubmitting, setFormSubmitting] = useState(false);

    // Fetch Rooms from Backend
    useEffect(() => {
        const fetchRooms = async () => {
            try {
                const data = await RoomApi.getAllRooms();
                setRooms(data);
            } catch (error) {
                toast.error("Error fetching rooms. Please try again.");
            } finally {
                setLoading(false);
            }
        };

        fetchRooms();
    }, []);

    // Handle Input Changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({
            ...form,
            [name]: name === "island" ? value === "true" : value,
        });
    };

    // Handle Form Submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setFormSubmitting(true);

        try {
            if (editingIndex !== null) {
                // Update Room
                const roomId = rooms[editingIndex].id;
                await RoomApi.updateRoom(roomId, form);
                const updatedRooms = [...rooms];
                updatedRooms[editingIndex] = { ...form, id: roomId };
                setRooms(updatedRooms);
                toast.success("Room updated successfully!");
                setEditingIndex(null);
            } else {
                // Create Room
                const newRoom = await RoomApi.createRoom(form);
                setRooms([...rooms, newRoom]);
                toast.success("Room created successfully!");
            }
            setForm({
                name: "",
                tables: 0,
                island: false,
            });
        } catch (error) {
            toast.error("Error saving room. Please try again.");
        } finally {
            setFormSubmitting(false);
        }
    };

    // Handle Edit
    const handleEdit = (index) => {
        setEditingIndex(index);
        setForm(rooms[index]);
    };

    // Handle Delete
    const handleDelete = async (index) => {
        const roomId = rooms[index].id;

        try {
            await RoomApi.deleteRoom(roomId);
            setRooms(rooms.filter((_, i) => i !== index));
            toast.success("Room deleted successfully!");
        } catch (error) {
            toast.error("Error deleting room. Please try again.");
        }
    };

    return (
        <div className={styles.roomManagementContainer}>
            <ToastContainer />
            <h1 className={styles.title}>Room Management</h1>

            {/* Room Form */}
            <form onSubmit={handleSubmit} className={styles.form}>
                <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="Room Name"
                    className={styles.input}
                    required
                />
                <input
                    type="number"
                    name="tables"
                    value={form.tables}
                    onChange={handleChange}
                    placeholder="Number of Tables"
                    className={styles.input}
                    required
                />
                <select
                    name="island"
                    value={form.island}
                    onChange={handleChange}
                    className={styles.select}
                    required
                >
                    <option value="" disabled>
                        Has Island?
                    </option>
                    <option value="true">Yes</option>
                    <option value="false">No</option>
                </select>
                <button
                    type="submit"
                    className={styles.submitButton}
                    disabled={formSubmitting}
                >
                    {formSubmitting
                        ? editingIndex !== null
                            ? "Updating..."
                            : "Adding..."
                        : editingIndex !== null
                            ? "Update Room"
                            : "Add Room"}
                </button>
            </form>

            {/* Room List */}
            <h2 className={styles.subtitle}>Room List</h2>
            {loading ? (
                <p className={styles.loading}>Loading rooms...</p>
            ) : rooms.length > 0 ? (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th>Room Name</th>
                        <th>Tables</th>
                        <th>Island</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {rooms.map((room, index) => (
                        <tr key={room.id}>
                            <td>{room.name}</td>
                            <td>{room.tables}</td>
                            <td>{room.island ? "Yes" : "No"}</td>
                            <td>
                                <button
                                    onClick={() => handleEdit(index)}
                                    className={styles.editButton}
                                >
                                    Edit
                                </button>
                                <button
                                    onClick={() => handleDelete(index)}
                                    className={styles.deleteButton}
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            ) : (
                <p className={styles.noData}>No rooms available. Add a room to get started.</p>
            )}
        </div>
    );
};

export default RoomManagement;
